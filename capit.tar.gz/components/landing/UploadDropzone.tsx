"use client";

import { useCallback, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { UploadCloud, Loader2, FileVideo } from "lucide-react";
import { useEditorStore } from "@/lib/useEditorStore";
import { buildDemoTranscript } from "@/lib/demoTranscript";
import { cn } from "@/lib/utils";

export function UploadDropzone() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const demoInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusText, setStatusText] = useState("");
  const [error, setError] = useState<string | null>(null);

  const setVideo = useEditorStore((s) => s.setVideo);
  const setWords = useEditorStore((s) => s.setWords);
  const setIsTranscribing = useEditorStore((s) => s.setIsTranscribing);

  const handleFile = useCallback(
    async (file: File, useDemo = false) => {
      setError(null);
      setIsProcessing(true);
      setStatusText("Reading video…");

      const url = URL.createObjectURL(file);
      const duration = await getVideoDuration(url);
      setVideo(url, file.name, duration);

      if (useDemo) {
        setStatusText("Generating demo captions…");
        await new Promise((r) => setTimeout(r, 600));
        setWords(buildDemoTranscript());
        setIsProcessing(false);
        router.push("/editor");
        return;
      }

      try {
        setIsTranscribing(true);
        setStatusText("Transcribing with Whisper — this can take a minute…");
        const formData = new FormData();
        formData.append("file", file);

        const res = await fetch("/api/transcribe", { method: "POST", body: formData });
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Transcription failed");
        }

        setWords(data.words);
        router.push("/editor");
      } catch (e) {
        setError(
          e instanceof Error
            ? e.message
            : "Something went wrong while transcribing. Try the demo mode instead."
        );
      } finally {
        setIsProcessing(false);
        setIsTranscribing(false);
      }
    },
    [router, setVideo, setWords, setIsTranscribing]
  );

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const file = e.dataTransfer.files?.[0];
      if (file) handleFile(file);
    },
    [handleFile]
  );

  return (
    <div className="w-full max-w-xl">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={cn(
          "relative cursor-pointer rounded-2xl border-2 border-dashed px-8 py-14 text-center transition-all",
          isDragging
            ? "border-accent bg-accent/5 scale-[1.01]"
            : "border-border-subtle bg-surface hover:border-foreground/30"
        )}
      >
        <input
          ref={inputRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file);
          }}
        />
        <input
          ref={demoInputRef}
          type="file"
          accept="video/*,audio/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleFile(file, true);
          }}
        />

        {isProcessing ? (
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="h-9 w-9 animate-spin text-accent" />
            <p className="text-sm text-foreground/70">{statusText}</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-3">
            <div className="rounded-full bg-surface-2 p-4">
              <UploadCloud className="h-7 w-7 text-accent" />
            </div>
            <p className="font-display text-lg font-semibold">
              Drop your video here, or click to browse
            </p>
            <p className="text-sm text-foreground/50">MP4, MOV, or audio · up to 500MB</p>
          </div>
        )}
      </div>

      {error && (
        <p className="mt-3 rounded-lg bg-red-950/40 px-4 py-3 text-sm text-red-300 border border-red-900/50">
          {error}
        </p>
      )}

      <div className="mt-4 flex items-center justify-center gap-2 text-sm text-foreground/40">
        <FileVideo className="h-4 w-4" />
        <span>Don&apos;t want to use an API key yet?</span>
        <button
          onClick={() => demoInputRef.current?.click()}
          className="font-medium text-accent hover:underline"
          type="button"
        >
          Try demo mode
        </button>
      </div>
    </div>
  );
}

function getVideoDuration(url: string): Promise<number> {
  return new Promise((resolve) => {
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => resolve(v.duration || 0);
    v.onerror = () => resolve(0);
    v.src = url;
  });
}
