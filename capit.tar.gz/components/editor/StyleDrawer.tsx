"use client";

import { useEditorStore } from "@/lib/useEditorStore";
import { STYLE_PRESETS, StylePresetId } from "@/lib/types";
import { cn } from "@/lib/utils";

const PRESET_LIST: { id: Exclude<StylePresetId, "custom">; label: string; blurb: string }[] = [
  { id: "hormozi", label: "Hormozi", blurb: "Bold yellow/green highlight" },
  { id: "mrbeast", label: "MrBeast", blurb: "Big bounce, red pop" },
  { id: "minimalist", label: "Minimalist", blurb: "Clean fade, lower-third" },
  { id: "neon", label: "Neon", blurb: "Glow highlight, center" },
];

export function StyleDrawer() {
  const style = useEditorStore((s) => s.style);
  const setStylePreset = useEditorStore((s) => s.setStylePreset);
  const updateStyle = useEditorStore((s) => s.updateStyle);

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border-subtle px-4 py-3">
        <h2 className="font-display text-sm font-semibold">Style</h2>
        <p className="text-xs text-foreground/40">Pick a preset, then fine-tune.</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4">
        <div className="grid grid-cols-2 gap-2">
          {PRESET_LIST.map((p) => {
            const preset = STYLE_PRESETS[p.id];
            const isActive = style.presetId === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setStylePreset(p.id)}
                className={cn(
                  "rounded-lg border px-3 py-3 text-left transition-colors",
                  isActive
                    ? "border-accent bg-accent/10"
                    : "border-border-subtle bg-surface hover:border-foreground/20"
                )}
              >
                <div
                  className="mb-1 text-sm font-bold"
                  style={{ color: preset.highlightColor, fontFamily: "var(--font-display)" }}
                >
                  {p.label}
                </div>
                <div className="text-[11px] text-foreground/40">{p.blurb}</div>
              </button>
            );
          })}
        </div>

        <div className="mt-6 space-y-5">
          <SectionLabel>Typography</SectionLabel>

          <Field label="Font size">
            <input
              type="range"
              min={28}
              max={90}
              value={style.fontSize}
              onChange={(e) => updateStyle({ fontSize: Number(e.target.value) })}
              className="w-full accent-accent"
            />
          </Field>

          <Field label="Words on screen">
            <input
              type="range"
              min={1}
              max={8}
              value={style.wordsPerLine}
              onChange={(e) => updateStyle({ wordsPerLine: Number(e.target.value) })}
              className="w-full accent-accent"
            />
          </Field>

          <Field label="Uppercase">
            <Toggle
              checked={style.uppercase}
              onChange={(v) => updateStyle({ uppercase: v })}
            />
          </Field>

          <SectionLabel>Colors</SectionLabel>

          <Field label="Text color">
            <ColorInput value={style.textColor} onChange={(v) => updateStyle({ textColor: v })} />
          </Field>

          <Field label="Highlight color">
            <ColorInput
              value={style.highlightColor}
              onChange={(v) => updateStyle({ highlightColor: v })}
            />
          </Field>

          <Field label="Highlight background">
            <ColorInput
              value={style.highlightBgColor ?? "#000000"}
              onChange={(v) => updateStyle({ highlightBgColor: v })}
              allowNone
              isNone={style.highlightBgColor === null}
              onNone={() => updateStyle({ highlightBgColor: null })}
            />
          </Field>

          <SectionLabel>Outline &amp; shadow</SectionLabel>

          <Field label="Stroke width">
            <input
              type="range"
              min={0}
              max={8}
              value={style.strokeWidth}
              onChange={(e) => updateStyle({ strokeWidth: Number(e.target.value) })}
              className="w-full accent-accent"
            />
          </Field>

          <Field label="Stroke color">
            <ColorInput value={style.strokeColor} onChange={(v) => updateStyle({ strokeColor: v })} />
          </Field>

          <SectionLabel>Layout</SectionLabel>

          <Field label="Position">
            <div className="flex gap-1.5">
              {(["top", "center", "bottom"] as const).map((pos) => (
                <button
                  key={pos}
                  onClick={() => updateStyle({ position: pos })}
                  className={cn(
                    "flex-1 rounded-md px-2 py-1.5 text-xs capitalize transition-colors",
                    style.position === pos
                      ? "bg-accent text-[#0a0a0c]"
                      : "bg-surface-2 text-foreground/60 hover:text-foreground"
                  )}
                >
                  {pos}
                </button>
              ))}
            </div>
          </Field>

          <Field label="Animation">
            <div className="flex flex-wrap gap-1.5">
              {(["pop", "bounce", "fade", "none"] as const).map((anim) => (
                <button
                  key={anim}
                  onClick={() => updateStyle({ animation: anim })}
                  className={cn(
                    "rounded-md px-2.5 py-1.5 text-xs capitalize transition-colors",
                    style.animation === anim
                      ? "bg-accent text-[#0a0a0c]"
                      : "bg-surface-2 text-foreground/60 hover:text-foreground"
                  )}
                >
                  {anim}
                </button>
              ))}
            </div>
          </Field>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-wide text-foreground/35">
      {children}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1.5 block text-xs text-foreground/50">{label}</label>
      {children}
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-6 w-11 rounded-full transition-colors",
        checked ? "bg-accent" : "bg-surface-2"
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform",
          checked ? "translate-x-5" : "translate-x-0.5"
        )}
      />
    </button>
  );
}

function ColorInput({
  value,
  onChange,
  allowNone,
  isNone,
  onNone,
}: {
  value: string;
  onChange: (v: string) => void;
  allowNone?: boolean;
  isNone?: boolean;
  onNone?: () => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="color"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-8 w-10 cursor-pointer rounded border border-border-subtle bg-transparent"
      />
      <span className="text-xs text-foreground/40">{isNone ? "none" : value}</span>
      {allowNone && (
        <button
          onClick={isNone ? () => onChange(value) : onNone}
          className="ml-auto text-[11px] text-accent hover:underline"
        >
          {isNone ? "Add" : "Remove"}
        </button>
      )}
    </div>
  );
}
