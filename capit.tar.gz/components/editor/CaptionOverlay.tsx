"use client";

import { CSSProperties } from "react";
import { CaptionStyleConfig } from "@/lib/types";
import { WordGroup } from "@/lib/groupWords";
import { cn } from "@/lib/utils";

const FONT_VAR_MAP: Record<string, string> = {
  Anton: "var(--font-anton)",
  "Luckiest Guy": "var(--font-luckiest-guy)",
  Poppins: "var(--font-poppins)",
  Inter: "var(--font-body)",
};

interface CaptionOverlayProps {
  group: WordGroup | null;
  activeWordId: string | null;
  style: CaptionStyleConfig;
  /** Scale factor relative to the 1080px-wide reference frame the style was authored for */
  scale: number;
}

export function CaptionOverlay({ group, activeWordId, style, scale }: CaptionOverlayProps) {
  if (!group) return null;

  const positionClass =
    style.position === "top"
      ? "top-[8%]"
      : style.position === "bottom"
      ? "bottom-[10%]"
      : "top-1/2 -translate-y-1/2";

  const containerStyle: CSSProperties = {
    fontFamily: FONT_VAR_MAP[style.fontFamily] ?? "var(--font-body)",
    fontSize: `${style.fontSize * scale}px`,
    fontWeight: 700,
    lineHeight: 1.15,
    textTransform: style.uppercase ? "uppercase" : "none",
    WebkitTextStroke:
      style.strokeWidth > 0 ? `${style.strokeWidth * scale}px ${style.strokeColor}` : undefined,
    textShadow:
      style.shadowBlur > 0
        ? `0 ${2 * scale}px ${style.shadowBlur * scale}px ${style.shadowColor}`
        : undefined,
    background: style.bgColor
      ? hexToRgba(style.bgColor, style.bgOpacity)
      : undefined,
    padding: style.bgColor
      ? `${style.bgPaddingY * scale}px ${style.bgPaddingX * scale}px`
      : undefined,
    borderRadius: style.bgColor ? 8 * scale : undefined,
  };

  return (
    <div
      className={cn("absolute left-1/2 -translate-x-1/2 z-10 flex w-[88%] flex-wrap justify-center gap-x-[0.35em] gap-y-1 text-center", positionClass)}
      style={containerStyle}
    >
      {group.words.map((w) => {
        const isActive = w.id === activeWordId;
        const animClass =
          style.animation === "pop"
            ? "anim-pop"
            : style.animation === "bounce"
            ? "anim-bounce"
            : style.animation === "fade"
            ? "anim-fade"
            : "";

        const wordStyle: CSSProperties = {
          color: isActive ? style.highlightColor : style.textColor,
          backgroundColor: isActive ? style.highlightBgColor ?? undefined : undefined,
          padding: isActive && style.highlightBgColor ? `0.05em 0.18em` : undefined,
          borderRadius: isActive && style.highlightBgColor ? "0.15em" : undefined,
          display: "inline-block",
        };

        return (
          <span
            key={w.id}
            style={wordStyle}
            className={isActive ? animClass : undefined}
          >
            {w.text}
          </span>
        );
      })}
    </div>
  );
}

function hexToRgba(hex: string, alpha: number): string {
  const clean = hex.replace("#", "");
  const bigint = parseInt(clean.length === 3 ? clean.replace(/(.)/g, "$1$1") : clean, 16);
  const r = (bigint >> 16) & 255;
  const g = (bigint >> 8) & 255;
  const b = bigint & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
