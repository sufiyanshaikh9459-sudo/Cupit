"use client";

import { useRef, useState } from "react";
import { Scissors, Combine, Trash2 } from "lucide-react";
import { useEditorStore } from "@/lib/useEditorStore";
import { groupWords } from "@/lib/groupWords";
import { formatTime, cn } from "@/lib/utils";

export function TranscriptSidebar() {
  const words = useEditorStore((s) => s.words);
  const style = useEditorStore((s) => s.style);
  const activeWordId = useEditorStore((s) => s.activeWordId);
  const seekTo = useEditorStore((s) => s.seekTo);
  const updateWordText = useEditorStore((s) => s.updateWordText);
  const splitAfterWord = useEditorStore((s) => s.splitAfterWord);
  const mergeWithNext = useEditorStore((s) => s.mergeWithNext);
  const deleteWord = useEditorStore((s) => s.deleteWord);
  const isTranscribing = useEditorStore((s) => s.isTranscribing);

  const groups = groupWords(words, style.wordsPerLine);

  if (isTranscribing) {
    return (
      <div className="flex h-full items-center justify-center p-8 text-sm text-foreground/40">
        Transcribing your audio…
      </div>
    );
  }

  if (words.length === 0) {
    return (
      <div className="flex h-full items-center justify-center p-8 text-center text-sm text-foreground/40">
        No transcript yet. Upload a video from the home page to get started.
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-border-subtle px-4 py-3">
        <h2 className="font-display text-sm font-semibold">Transcript</h2>
        <p className="text-xs text-foreground/40">
          Click a word to jump there. Edit text inline. Hover for split/merge.
        </p>
      </div>
      <div className="flex-1 overflow-y-auto px-3 py-3">
        {groups.map((group, gi) => (
          <div
            key={group.id}
            className="group mb-2 rounded-lg border border-border-subtle bg-surface px-3 py-2.5 transition-colors hover:border-foreground/20"
          >
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-wide text-foreground/30">
                {formatTime(group.start)}
              </span>
              <span className="text-[10px] text-foreground/30">Group {gi + 1}</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {group.words.map((w) => (
                <WordChip
                  key={w.id}
                  word={w}
                  isActive={w.id === activeWordId}
                  onSeek={() => seekTo(w.start)}
                  onEdit={(text) => updateWordText(w.id, text)}
                  onSplit={() => splitAfterWord(w.id)}
                  onMerge={() => mergeWithNext(w.id)}
                  onDelete={() => deleteWord(w.id)}
                  isLastInGroup={w.id === group.words[group.words.length - 1].id}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

interface WordChipProps {
  word: { id: string; text: string; start: number; end: number };
  isActive: boolean;
  isLastInGroup: boolean;
  onSeek: () => void;
  onEdit: (text: string) => void;
  onSplit: () => void;
  onMerge: () => void;
  onDelete: () => void;
}

function WordChip({ word, isActive, isLastInGroup, onSeek, onEdit, onSplit, onMerge, onDelete }: WordChipProps) {
  const [isEditing, setIsEditing] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div
      className={cn(
        "group/word relative flex items-center gap-1 rounded-md px-2 py-1 text-sm transition-colors",
        isActive ? "bg-accent text-[#0a0a0c]" : "bg-surface-2 hover:bg-surface-2/70"
      )}
    >
      {isEditing ? (
        <input
          ref={inputRef}
          autoFocus
          defaultValue={word.text}
          onBlur={(e) => {
            onEdit(e.target.value);
            setIsEditing(false);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              onEdit((e.target as HTMLInputElement).value);
              setIsEditing(false);
            }
            if (e.key === "Escape") setIsEditing(false);
          }}
          className="w-20 bg-transparent text-sm outline-none"
        />
      ) : (
        <button
          onClick={onSeek}
          onDoubleClick={() => setIsEditing(true)}
          className="max-w-[160px] truncate"
          title="Click to seek · double-click to edit"
        >
          {word.text}
        </button>
      )}

      <div className="hidden items-center gap-0.5 group-hover/word:flex">
        {!isLastInGroup ? (
          <button
            onClick={onSplit}
            title="Split here"
            className="rounded p-0.5 text-current/60 hover:text-current"
          >
            <Scissors className="h-3 w-3" />
          </button>
        ) : (
          <button
            onClick={onMerge}
            title="Merge with next group"
            className="rounded p-0.5 text-current/60 hover:text-current"
          >
            <Combine className="h-3 w-3" />
          </button>
        )}
        <button
          onClick={onDelete}
          title="Delete word"
          className="rounded p-0.5 text-current/60 hover:text-red-400"
        >
          <Trash2 className="h-3 w-3" />
        </button>
      </div>
    </div>
  );
}
