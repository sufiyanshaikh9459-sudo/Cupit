"use client";

import { useEffect, useRef, useState } from "react";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { useEditorStore } from "@/lib/useEditorStore";
import { groupWords, findActiveGroup } from "@/lib/groupWords";
import { CaptionOverlay } from "./CaptionOverlay";
import { cn } from "@/lib/utils";

const REFERENCE_WIDTH = 1080;

export function VideoCanvas() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [frameWidth, setFrameWidth] = useState(360);
  const [muted, setMuted] = useState(false);

  const videoUrl = useEditorStore((s) => s.videoUrl);
  const words = useEditorStore((s) => s.words);
  const style = useEditorStore((s) => s.style);
  const isPlaying = useEditorStore((s) => s.isPlaying);
  const activeWordId = useEditorStore((s) => s.activeWordId);
  const currentTime = useEditorStore((s) => s.currentTime);
  const setCurrentTime = useEditorStore((s) => s.setCurrentTime);
  const setIsPlaying = useEditorStore((s) => s.setIsPlaying);

  const groups = groupWords(words, style.wordsPerLine);
  const activeGroup = findActiveGroup(groups, currentTime);

  // Track container width to scale caption typography proportionally
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setFrameWidth(entry.contentRect.width);
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Drive store currentTime from the actual <video> element via rAF for
  // smooth, frequent updates (timeupdate alone fires too infrequently).
  useEffect(() => {
    let raf: number;
    const tick = () => {
      const v = videoRef.current;
      if (v && !v.paused) {
        setCurrentTime(v.currentTime);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [setCurrentTime]);

  // External seeks (e.g. clicking a word in the transcript) should move the
  // actual <video> element. We detect this by checking if the store's time
  // diverged from the video's time by more than a frame, and the video is
  // not currently driving the update itself (i.e. paused, or a manual seek).
  const lastSyncedTime = useRef(0);
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (Math.abs(currentTime - lastSyncedTime.current) > 0.05 && Math.abs(v.currentTime - currentTime) > 0.2) {
      v.currentTime = currentTime;
    }
    lastSyncedTime.current = currentTime;
  }, [currentTime]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (isPlaying) v.play().catch(() => {});
    else v.pause();
  }, [isPlaying]);

  const scale = frameWidth / REFERENCE_WIDTH;

  if (!videoUrl) {
    return (
      <div className="flex aspect-[9/16] w-full max-w-sm items-center justify-center rounded-2xl border border-border-subtle bg-surface text-sm text-foreground/40">
        No video loaded
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <div
        ref={containerRef}
        className="relative aspect-[9/16] w-full max-w-sm overflow-hidden rounded-2xl border border-border-subtle bg-black shadow-2xl shadow-black/50"
      >
        <video
          ref={videoRef}
          src={videoUrl}
          muted={muted}
          className="h-full w-full object-cover"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={() => setIsPlaying(false)}
        />
        <CaptionOverlay group={activeGroup} activeWordId={activeWordId} style={style} scale={scale} />
      </div>

      <div className="flex w-full max-w-sm items-center justify-between rounded-xl border border-border-subtle bg-surface px-4 py-2.5">
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="flex items-center gap-2 text-sm font-medium"
        >
          {isPlaying ? (
            <Pause className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4" />
          )}
          {isPlaying ? "Pause" : "Play"}
        </button>
        <button onClick={() => setMuted((m) => !m)} className={cn("text-foreground/60 hover:text-foreground")}>
          {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </button>
      </div>
    </div>
  );
}
