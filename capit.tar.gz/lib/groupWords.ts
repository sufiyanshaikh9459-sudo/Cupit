import { Word } from "./types";

export interface WordGroup {
  id: string;
  words: Word[];
  start: number;
  end: number;
}

/**
 * Groups a flat word array into on-screen caption chunks.
 *
 * Rules:
 * - A group ends when it reaches `wordsPerLine` words.
 * - A group also ends early if a word has `breakAfter: true` (manual split).
 * - A `breakAfter: false` on a word that would otherwise have ended a group
 *   (because count was reached) only matters in combination with the count;
 *   explicit merges are handled by the caller adjusting wordsPerLine logic —
 *   here we simply respect breakAfter as a hard "yes, break here" signal and
 *   never insert a break early unless wordsPerLine count is hit, UNLESS
 *   breakAfter is explicitly true.
 */
export function groupWords(words: Word[], wordsPerLine: number): WordGroup[] {
  const groups: WordGroup[] = [];
  let current: Word[] = [];

  for (const w of words) {
    current.push(w);
    const hitCount = current.length >= Math.max(1, wordsPerLine);
    const manualBreak = w.breakAfter === true;

    if (hitCount || manualBreak) {
      groups.push(makeGroup(current));
      current = [];
    }
  }
  if (current.length > 0) {
    groups.push(makeGroup(current));
  }
  return groups;
}

function makeGroup(words: Word[]): WordGroup {
  return {
    id: words.map((w) => w.id).join("-"),
    words,
    start: words[0].start,
    end: words[words.length - 1].end,
  };
}

export function findActiveGroup(groups: WordGroup[], time: number): WordGroup | null {
  return groups.find((g) => time >= g.start && time < g.end) ?? null;
}
