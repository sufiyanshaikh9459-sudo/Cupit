import { CaptionStyleConfig } from "@/lib/types";
import { groupWords } from "@/lib/groupWords";
import type { Word } from "@/lib/types";

const ASS_FONT_MAP: Record<string, string> = {
  Anton: "Anton",
  "Luckiest Guy": "Luckiest Guy",
  Poppins: "Poppins",
  Inter: "Inter Tight",
};

/**
 * Builds a full .ass subtitle file string with one styled event per on-screen
 * word group. Active-word highlighting is done by emitting one event PER
 * WORD within the group's time range (rather than relying on \k karaoke,
 * which libass renders inconsistently across builds) — each event shows the
 * full group's text but recolors only the word that's "active" during that
 * sub-interval. This guarantees identical visual behavior to the live
 * browser preview.
 */
export function buildAssSubtitle(
  words: Word[],
  style: CaptionStyleConfig,
  videoWidth: number,
  videoHeight: number
): string {
  const groups = groupWords(words, style.wordsPerLine);
  const refScale = videoWidth / 1080;

  const fontName = ASS_FONT_MAP[style.fontFamily] ?? "Inter Tight";
  const fontSize = Math.round(style.fontSize * refScale);
  const primaryColor = assColor(style.textColor);
  const outlineColor = assColor(style.strokeColor === "transparent" ? "#000000" : style.strokeColor);
  const outlineWidth = style.strokeWidth > 0 ? Math.max(1, Math.round(style.strokeWidth * refScale)) : 0;
  const alignment = style.position === "top" ? 8 : style.position === "bottom" ? 2 : 5;
  const marginV =
    style.position === "top"
      ? Math.round(videoHeight * 0.08)
      : style.position === "bottom"
      ? Math.round(videoHeight * 0.1)
      : Math.round(videoHeight * 0.5);

  // When the style specifies a line-level background (e.g. the Minimalist
  // preset's lower-third box), use BorderStyle 3 (opaque box) with BackColour
  // carrying the configured color + opacity. Otherwise fall back to a normal
  // outlined-text style (BorderStyle 1) with no box.
  const hasBgBox = !!style.bgColor;
  const borderStyle = hasBgBox ? 3 : 1;
  const backColor = hasBgBox
    ? assColorWithAlpha(style.bgColor!, style.bgOpacity)
    : "&H00000000";
  // BorderStyle 3's "outline" value doubles as the box padding in libass.
  const boxPadding = hasBgBox
    ? Math.max(outlineWidth, Math.round(style.bgPaddingY * refScale * 0.5) || 4)
    : outlineWidth;

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${videoWidth}
PlayResY: ${videoHeight}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${fontName},${fontSize},${primaryColor},${primaryColor},${outlineColor},${backColor},-1,0,0,0,100,100,0,0,${borderStyle},${boxPadding},2,${alignment},40,40,${marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const lines: string[] = [];

  for (const group of groups) {
    // Emit one event per word so the active word's color/highlight can change
    // within the group's display window, matching the live preview exactly.
    for (let i = 0; i < group.words.length; i++) {
      const activeWord = group.words[i];
      const segStart = activeWord.start;
      const segEnd = i < group.words.length - 1 ? group.words[i + 1].start : group.end;

      const text = group.words
        .map((w) => {
          const display = style.uppercase ? w.text.toUpperCase() : w.text;
          const escaped = escapeAssText(display);
          if (w.id === activeWord.id) {
            // NOTE: style.highlightBgColor (the per-word pill background used
            // by the Hormozi preset in the live preview) has no clean ASS
            // equivalent — libass only supports one box per dialogue line,
            // not per-word. We approximate the highlight with a color swap
            // only. This is a known, intentional fidelity gap vs. the
            // browser preview; a pixel-perfect match would require rendering
            // each word as a separate positioned dialogue event with \pos,
            // which is a larger change saved for a future pass.
            const hl = assColor(style.highlightColor);
            return `{\\c${hl}}${escaped}{\\c${primaryColor}}`;
          }
          return escaped;
        })
        .join(" ");

      lines.push(
        `Dialogue: 0,${formatAssTime(segStart)},${formatAssTime(segEnd)},Default,,0,0,0,,${text}`
      );
    }
  }

  return header + lines.join("\n") + "\n";
}

function formatAssTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const cs = Math.floor((seconds % 1) * 100);
  return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}.${cs
    .toString()
    .padStart(2, "0")}`;
}

/** Converts #RRGGBB to ASS's &HBBGGRR& format */
function assColor(hex: string): string {
  const clean = hex.replace("#", "");
  if (clean.length !== 6) return "&H00FFFFFF&";
  const r = clean.slice(0, 2);
  const g = clean.slice(2, 4);
  const b = clean.slice(4, 6);
  return `&H00${b}${g}${r}&`.toUpperCase();
}

/**
 * Converts #RRGGBB + a 0-1 opacity into ASS's &HAABBGGRR& format. ASS alpha
 * is inverted relative to CSS: 00 = fully opaque, FF = fully transparent.
 */
function assColorWithAlpha(hex: string, opacity: number): string {
  const clean = hex.replace("#", "");
  if (clean.length !== 6) return "&H00000000&";
  const r = clean.slice(0, 2);
  const g = clean.slice(2, 4);
  const b = clean.slice(4, 6);
  const clampedOpacity = Math.min(1, Math.max(0, opacity));
  const alpha = Math.round((1 - clampedOpacity) * 255);
  const alphaHex = alpha.toString(16).padStart(2, "0");
  return `&H${alphaHex}${b}${g}${r}&`.toUpperCase();
}

function escapeAssText(text: string): string {
  return text.replace(/\{/g, "(").replace(/\}/g, ")");
}
