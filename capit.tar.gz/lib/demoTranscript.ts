import { Word } from "./types";
import { uid } from "./utils";

/**
 * Generates a deterministic demo word-timing array so the editor can be
 * exercised without hitting a paid transcription API. Includes a Hinglish
 * (Hindi+English code-switched) line to demonstrate mixed-dialect handling.
 */
export function buildDemoTranscript(): Word[] {
  const lines: { text: string; wpm?: number }[] = [
    { text: "Yeh video dekho bhai, this one is actually crazy" },
    { text: "Main aapko bata raha hoon ek simple trick" },
    { text: "Bro check this out before you scroll away" },
    { text: "Ek minute mein tumhari life change ho sakti hai" },
  ];

  const words: Word[] = [];
  let t = 0.2;
  for (const line of lines) {
    for (const raw of line.text.split(" ")) {
      const dur = 0.18 + Math.min(raw.length, 8) * 0.035;
      words.push({
        id: uid(),
        text: raw,
        start: round(t),
        end: round(t + dur),
        confidence: 0.9 + Math.random() * 0.09,
      });
      t += dur + 0.05;
    }
    t += 0.25; // pause between lines
  }
  return words;
}

function round(n: number) {
  return Math.round(n * 100) / 100;
}
