import { create } from "zustand";
import { CaptionStyleConfig, STYLE_PRESETS, StylePresetId, Word } from "./types";

interface EditorState {
  // Source
  videoUrl: string | null;
  videoName: string;
  duration: number;

  // Transcript
  words: Word[];
  isTranscribing: boolean;
  transcribeError: string | null;

  // Playback
  currentTime: number;
  isPlaying: boolean;
  activeWordId: string | null;

  // Style
  style: CaptionStyleConfig;

  // Selection (for editing UI)
  selectedSegmentStart: number | null; // index into words[] marking a manual segment break

  // Export
  isExporting: boolean;
  exportProgress: number;
  exportUrl: string | null;
  exportError: string | null;

  // Actions
  setVideo: (url: string, name: string, duration: number) => void;
  setWords: (words: Word[]) => void;
  setIsTranscribing: (v: boolean) => void;
  setTranscribeError: (e: string | null) => void;

  setCurrentTime: (t: number) => void;
  setIsPlaying: (v: boolean) => void;
  seekTo: (t: number) => void;

  updateWordText: (id: string, text: string) => void;
  splitAfterWord: (id: string) => void;
  mergeWithNext: (id: string) => void;
  deleteWord: (id: string) => void;

  setStylePreset: (preset: StylePresetId) => void;
  updateStyle: (partial: Partial<CaptionStyleConfig>) => void;

  setExporting: (v: boolean) => void;
  setExportProgress: (n: number) => void;
  setExportUrl: (url: string | null) => void;
  setExportError: (e: string | null) => void;

  reset: () => void;
}

// Manual break markers: we store group boundaries as a Set of word ids that
// START a new on-screen group. By default every `wordsPerLine`-th word starts
// a group, but split/merge can override this per-project.
export const useEditorStore = create<EditorState>((set, get) => ({
  videoUrl: null,
  videoName: "",
  duration: 0,

  words: [],
  isTranscribing: false,
  transcribeError: null,

  currentTime: 0,
  isPlaying: false,
  activeWordId: null,

  style: STYLE_PRESETS.hormozi,

  selectedSegmentStart: null,

  isExporting: false,
  exportProgress: 0,
  exportUrl: null,
  exportError: null,

  setVideo: (url, name, duration) => set({ videoUrl: url, videoName: name, duration }),

  setWords: (words) => set({ words }),
  setIsTranscribing: (v) => set({ isTranscribing: v }),
  setTranscribeError: (e) => set({ transcribeError: e }),

  setCurrentTime: (t) => {
    const { words } = get();
    const active = words.find((w) => t >= w.start && t < w.end);
    set({ currentTime: t, activeWordId: active ? active.id : null });
  },
  setIsPlaying: (v) => set({ isPlaying: v }),
  seekTo: (t) => set({ currentTime: t }),

  updateWordText: (id, text) =>
    set((state) => ({
      words: state.words.map((w) => (w.id === id ? { ...w, text } : w)),
    })),

  splitAfterWord: (id) =>
    set((state) => ({
      words: state.words.map((w) => (w.id === id ? { ...w, breakAfter: true } : w)),
    })),

  mergeWithNext: (id) =>
    set((state) => ({
      words: state.words.map((w) => (w.id === id ? { ...w, breakAfter: false } : w)),
    })),

  deleteWord: (id) =>
    set((state) => ({
      words: state.words.filter((w) => w.id !== id),
    })),

  setStylePreset: (preset) =>
    set({ style: preset === "custom" ? get().style : STYLE_PRESETS[preset] }),

  updateStyle: (partial) =>
    set((state) => ({ style: { ...state.style, ...partial, presetId: "custom" } })),

  setExporting: (v) => set({ isExporting: v }),
  setExportProgress: (n) => set({ exportProgress: n }),
  setExportUrl: (url) => set({ exportUrl: url }),
  setExportError: (e) => set({ exportError: e }),

  reset: () =>
    set({
      videoUrl: null,
      videoName: "",
      duration: 0,
      words: [],
      isTranscribing: false,
      transcribeError: null,
      currentTime: 0,
      isPlaying: false,
      activeWordId: null,
      style: STYLE_PRESETS.hormozi,
      selectedSegmentStart: null,
      isExporting: false,
      exportProgress: 0,
      exportUrl: null,
      exportError: null,
    }),
}));
