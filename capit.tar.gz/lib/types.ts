// Core data model for cap.it

export interface Word {
  id: string;
  text: string;
  start: number; // seconds
  end: number; // seconds
  confidence: number;
  /** Manual override: force a new on-screen group to start right after this word */
  breakAfter?: boolean;
}

export interface SubtitleSegment {
  id: string;
  words: Word[];
  start: number;
  end: number;
}

export type StylePresetId = "hormozi" | "mrbeast" | "minimalist" | "neon" | "custom";

export interface CaptionStyleConfig {
  presetId: StylePresetId;
  fontFamily: string;
  fontSize: number; // px at 1080-wide reference frame
  textColor: string;
  highlightColor: string;
  highlightBgColor: string | null; // box behind active word
  strokeColor: string;
  strokeWidth: number; // px
  shadowColor: string;
  shadowBlur: number;
  uppercase: boolean;
  bgPaddingX: number;
  bgPaddingY: number;
  bgColor: string | null;
  bgOpacity: number;
  position: "top" | "center" | "bottom";
  animation: "pop" | "bounce" | "fade" | "none";
  wordsPerLine: number; // how many words shown at once on screen
}

export const STYLE_PRESETS: Record<Exclude<StylePresetId, "custom">, CaptionStyleConfig> = {
  hormozi: {
    presetId: "hormozi",
    fontFamily: "Anton",
    fontSize: 64,
    textColor: "#ffffff",
    highlightColor: "#fff200",
    highlightBgColor: "#16a34a",
    strokeColor: "#000000",
    strokeWidth: 3,
    shadowColor: "rgba(0,0,0,0.6)",
    shadowBlur: 8,
    uppercase: true,
    bgPaddingX: 14,
    bgPaddingY: 8,
    bgColor: null,
    bgOpacity: 1,
    position: "center",
    animation: "pop",
    wordsPerLine: 3,
  },
  mrbeast: {
    presetId: "mrbeast",
    fontFamily: "Luckiest Guy",
    fontSize: 70,
    textColor: "#ffffff",
    highlightColor: "#ff3d3d",
    highlightBgColor: null,
    strokeColor: "#000000",
    strokeWidth: 5,
    shadowColor: "rgba(0,0,0,0.5)",
    shadowBlur: 4,
    uppercase: true,
    bgPaddingX: 0,
    bgPaddingY: 0,
    bgColor: null,
    bgOpacity: 1,
    position: "center",
    animation: "bounce",
    wordsPerLine: 2,
  },
  minimalist: {
    presetId: "minimalist",
    fontFamily: "Inter",
    fontSize: 46,
    textColor: "#ffffff",
    highlightColor: "#ffffff",
    highlightBgColor: null,
    strokeColor: "transparent",
    strokeWidth: 0,
    shadowColor: "rgba(0,0,0,0.4)",
    shadowBlur: 6,
    uppercase: false,
    bgPaddingX: 16,
    bgPaddingY: 10,
    bgColor: "#000000",
    bgOpacity: 0.55,
    position: "bottom",
    animation: "fade",
    wordsPerLine: 5,
  },
  neon: {
    presetId: "neon",
    fontFamily: "Poppins",
    fontSize: 56,
    textColor: "#f5f5f5",
    highlightColor: "#00f0ff",
    highlightBgColor: null,
    strokeColor: "#0a0a0a",
    strokeWidth: 2,
    shadowColor: "#00f0ff",
    shadowBlur: 18,
    uppercase: false,
    bgPaddingX: 0,
    bgPaddingY: 0,
    bgColor: null,
    bgOpacity: 1,
    position: "center",
    animation: "pop",
    wordsPerLine: 4,
  },
};

export interface VideoProject {
  id: string;
  name: string;
  videoUrl: string;
  duration: number;
  words: Word[];
  style: CaptionStyleConfig;
  createdAt: number;
}
