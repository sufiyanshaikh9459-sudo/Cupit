import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { uid } from "@/lib/utils";
import type { Word } from "@/lib/types";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        {
          error:
            "OPENAI_API_KEY is not configured on the server. Add it to your .env.local to enable real transcription.",
        },
        { status: 500 }
      );
    }

    const client = new OpenAI({ apiKey });

    // Whisper API word-level timestamps via verbose_json + timestamp_granularities
    const transcription = await client.audio.transcriptions.create({
      file,
      model: "whisper-1",
      response_format: "verbose_json",
      timestamp_granularities: ["word"],
    });

    // The SDK types verbose_json loosely; words[] is present at runtime when
    // timestamp_granularities includes "word".
    const raw = transcription as unknown as {
      words?: { word: string; start: number; end: number }[];
      text?: string;
    };

    if (!raw.words || raw.words.length === 0) {
      return NextResponse.json(
        { error: "Transcription succeeded but returned no word-level timestamps." },
        { status: 502 }
      );
    }

    const words: Word[] = raw.words.map((w) => ({
      id: uid(),
      text: w.word.trim(),
      start: round(w.start),
      end: round(w.end),
      confidence: 0.95,
    }));

    return NextResponse.json({ words });
  } catch (err) {
    console.error("Transcription error:", err);
    const message = err instanceof Error ? err.message : "Unknown transcription error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

function round(n: number) {
  return Math.round(n * 100) / 100;
}
