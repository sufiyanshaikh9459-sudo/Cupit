import { NextRequest, NextResponse } from "next/server";
import { spawn } from "child_process";
import { mkdtemp, writeFile, readFile, rm } from "fs/promises";
import { tmpdir } from "os";
import path from "path";
import { buildAssSubtitle } from "@/lib/export/buildAssSubtitle";
import type { Word, CaptionStyleConfig } from "@/lib/types";

export const runtime = "nodejs";
export const maxDuration = 300;

// Reference output resolution for portrait short-form video.
const OUTPUT_WIDTH = 1080;
const OUTPUT_HEIGHT = 1920;

export async function POST(req: NextRequest) {
  let workDir: string | null = null;

  try {
    const formData = await req.formData();
    const videoFile = formData.get("video") as File | null;
    const wordsRaw = formData.get("words") as string | null;
    const styleRaw = formData.get("style") as string | null;

    if (!videoFile || !wordsRaw || !styleRaw) {
      return NextResponse.json({ error: "Missing video, words, or style payload" }, { status: 400 });
    }

    const words: Word[] = JSON.parse(wordsRaw);
    const style: CaptionStyleConfig = JSON.parse(styleRaw);

    workDir = await mkdtemp(path.join(tmpdir(), "capit-export-"));
    const inputPath = path.join(workDir, "input" + extFromName(videoFile.name));
    const assPath = path.join(workDir, "captions.ass");
    const outputPath = path.join(workDir, "output.mp4");

    const inputBuffer = Buffer.from(await videoFile.arrayBuffer());
    await writeFile(inputPath, inputBuffer);

    const assContent = buildAssSubtitle(words, style, OUTPUT_WIDTH, OUTPUT_HEIGHT);
    await writeFile(assPath, assContent, "utf-8");

    await runFfmpeg(inputPath, assPath, outputPath);

    const outputBuffer = await readFile(outputPath);

    return new NextResponse(outputBuffer, {
      status: 200,
      headers: {
        "Content-Type": "video/mp4",
        "Content-Disposition": 'attachment; filename="capit-export.mp4"',
      },
    });
  } catch (err) {
    console.error("Export error:", err);
    const message = err instanceof Error ? err.message : "Unknown export error";
    return NextResponse.json({ error: message }, { status: 500 });
  } finally {
    if (workDir) {
      await rm(workDir, { recursive: true, force: true }).catch(() => {});
    }
  }
}

function extFromName(name: string): string {
  const match = name.match(/\.[a-zA-Z0-9]+$/);
  return match ? match[0] : ".mp4";
}

function runFfmpeg(inputPath: string, assPath: string, outputPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    // Scale/crop to portrait 1080x1920, then burn in the ASS subtitle track.
    // The subtitles filter expects forward slashes and escaped colons on
    // some platforms; path.join output on POSIX is fine as-is.
    const vf = `scale=${OUTPUT_WIDTH}:${OUTPUT_HEIGHT}:force_original_aspect_ratio=increase,crop=${OUTPUT_WIDTH}:${OUTPUT_HEIGHT},ass=${escapeFilterPath(
      assPath
    )}`;

    const args = [
      "-y",
      "-i",
      inputPath,
      "-vf",
      vf,
      "-c:v",
      "libx264",
      "-preset",
      "veryfast",
      "-crf",
      "20",
      "-c:a",
      "aac",
      "-b:a",
      "160k",
      "-movflags",
      "+faststart",
      outputPath,
    ];

    const proc = spawn("ffmpeg", args);

    let stderr = "";
    proc.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
    });

    proc.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`ffmpeg exited with code ${code}: ${stderr.slice(-1500)}`));
    });

    proc.on("error", (err) => {
      reject(new Error(`Failed to start ffmpeg: ${err.message}. Is ffmpeg installed on this server?`));
    });
  });
}

function escapeFilterPath(p: string): string {
  // ffmpeg filter graph syntax treats ':' as an option separator, so escape
  // any colons in the path (relevant mainly on Windows-style paths).
  return p.replace(/:/g, "\\:");
}
