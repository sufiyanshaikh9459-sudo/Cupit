import { UploadDropzone } from "@/components/landing/UploadDropzone";
import { ArrowUpRight, Captions, Languages, Zap } from "lucide-react";

const MARQUEE_WORDS = [
  "yeh video dekho",
  "BRO CHECK THIS OUT",
  "c'est incroyable",
  "literally insane",
  "no cap fr fr",
  "ek minute mein",
];

export default function Home() {
  return (
    <main className="relative flex-1 overflow-hidden">
      <div className="grain" />

      {/* Top nav */}
      <header className="relative z-10 flex items-center justify-between px-6 py-6 md:px-10">
        <div className="font-display text-xl font-bold tracking-tight">
          cap<span className="text-accent">.</span>it
        </div>
        <nav className="flex items-center gap-6 text-sm text-foreground/60">
          <a href="#how" className="hover:text-foreground transition-colors">
            How it works
          </a>
          <a href="#styles" className="hover:text-foreground transition-colors">
            Styles
          </a>
          <button className="rounded-full bg-surface-2 px-4 py-2 text-foreground hover:bg-surface-2/70 transition-colors">
            Sign in
          </button>
        </nav>
      </header>

      {/* Hero */}
      <section className="relative z-10 flex flex-col items-center px-6 pt-16 pb-10 text-center md:pt-24">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border-subtle bg-surface px-4 py-1.5 text-xs text-foreground/60">
          <Languages className="h-3.5 w-3.5 text-accent" />
          Built for Hinglish, Spanish, French &amp; English creators
        </div>

        <h1 className="font-display max-w-3xl text-5xl font-extrabold leading-[1.05] tracking-tight md:text-7xl">
          Captions that move
          <br />
          like your <span className="text-accent">audience</span> does
        </h1>

        <p className="mt-6 max-w-xl text-balance text-lg text-foreground/55">
          Drop a clip. Get word-by-word kinetic subtitles, styled to match the trends
          that actually get watched — in seconds, not hours.
        </p>

        <div className="mt-10 flex w-full justify-center">
          <UploadDropzone />
        </div>
      </section>

      {/* Marquee strip */}
      <div className="relative z-10 mt-12 overflow-hidden border-y border-border-subtle bg-surface py-4">
        <div className="flex w-max animate-marquee gap-10 whitespace-nowrap">
          {[...MARQUEE_WORDS, ...MARQUEE_WORDS, ...MARQUEE_WORDS].map((w, i) => (
            <span
              key={i}
              className="font-display text-2xl font-bold uppercase tracking-tight text-foreground/15"
            >
              {w}
            </span>
          ))}
        </div>
      </div>

      {/* Feature grid */}
      <section id="how" className="relative z-10 mx-auto max-w-5xl px-6 py-24">
        <div className="grid gap-6 md:grid-cols-3">
          <FeatureCard
            icon={<Zap className="h-5 w-5" />}
            title="Word-level alignment"
            desc="Every word gets its own exact timestamp, so highlights snap perfectly to speech — even fast code-switched lines."
          />
          <FeatureCard
            icon={<Captions className="h-5 w-5" />}
            title="Click-to-seek transcript"
            desc="Click any word in the sidebar and the playhead jumps straight there. Fix a typo and it mirrors instantly on the canvas."
          />
          <FeatureCard
            icon={<Languages className="h-5 w-5" />}
            title="Mixed-dialect aware"
            desc="Hinglish, Spanglish, and other code-switched speech are transcribed and capitalized the way creators actually write them."
          />
        </div>
      </section>

      {/* Style presets preview */}
      <section id="styles" className="relative z-10 mx-auto max-w-5xl px-6 pb-28">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-display text-2xl font-bold">Pick a vibe, not a template</h2>
          <a
            href="#"
            className="flex items-center gap-1 text-sm text-accent hover:underline"
          >
            See all presets <ArrowUpRight className="h-3.5 w-3.5" />
          </a>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
          <StyleChip name="Hormozi" sub="bold yellow/green" color="#fff200" bg="#16a34a" />
          <StyleChip name="MrBeast" sub="bounce + red pop" color="#ff3d3d" bg="#000000" />
          <StyleChip name="Minimalist" sub="clean fade" color="#ffffff" bg="#1c1c20" />
          <StyleChip name="Neon" sub="glow highlight" color="#00f0ff" bg="#0a0a0c" />
        </div>
      </section>

      <footer className="relative z-10 border-t border-border-subtle px-6 py-8 text-center text-xs text-foreground/35">
        cap.it — built for creators who edit fast and post faster.
      </footer>
    </main>
  );
}

function FeatureCard({
  icon,
  title,
  desc,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <div className="rounded-2xl border border-border-subtle bg-surface p-6">
      <div className="mb-4 inline-flex rounded-lg bg-accent/10 p-2.5 text-accent">{icon}</div>
      <h3 className="font-display mb-2 text-base font-semibold">{title}</h3>
      <p className="text-sm leading-relaxed text-foreground/55">{desc}</p>
    </div>
  );
}

function StyleChip({
  name,
  sub,
  color,
  bg,
}: {
  name: string;
  sub: string;
  color: string;
  bg: string;
}) {
  return (
    <div
      className="flex aspect-[9/12] flex-col items-center justify-center rounded-xl border border-border-subtle"
      style={{ background: bg }}
    >
      <span
        className="font-display text-xl font-extrabold uppercase"
        style={{ color }}
      >
        {name}
      </span>
      <span className="mt-1 text-xs text-white/50">{sub}</span>
    </div>
  );
}
