import type { Metadata } from "next";
import "./globals.css";

// NOTE: This sandbox environment cannot reach fonts.googleapis.com, so
// next/font/google fails at build time here. In a normal deployment (e.g.
// Vercel) with standard internet access, swap this block back to:
//
//   import { Bricolage_Grotesque, Inter_Tight, Anton, Poppins, Luckiest_Guy } from "next/font/google";
//   const display = Bricolage_Grotesque({ variable: "--font-display", subsets: ["latin"], weight: [...] });
//   ...etc, and add `${display.variable} ${body.variable} ...` to the html className below.
//
// For now we declare the same CSS variables via @font-face in globals.css
// pointing at Google Fonts' CDN directly, which the *browser* (not the build
// step) fetches at runtime — so the visual result is identical.

export const metadata: Metadata = {
  title: "cap.it — kinetic captions for short-form video",
  description:
    "Upload, auto-caption, and style word-by-word kinetic subtitles for Reels, TikTok and Shorts — built for multilingual and Hinglish content.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col bg-[#0a0a0c] text-[#f2f1ed]">{children}</body>
    </html>
  );
}
