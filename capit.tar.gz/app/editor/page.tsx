"use client";

import Link from "next/link";
import { ArrowLeft, Download, Loader2 } from "lucide-react";
import { useEditorStore } from "@/lib/useEditorStore";
import { VideoCanvas } from "@/components/editor/VideoCanvas";
import { TranscriptSidebar } from "@/components/editor/TranscriptSidebar";
import { StyleDrawer } from "@/components/editor/StyleDrawer";
import { useState } from "react";

export default function EditorPage() {
  const videoUrl = useEditorStore((s) => s.videoUrl);
  const videoName = useEditorStore((s) => s.videoName);
  const words = useEditorStore((s) => s.words);
  const style = useEditorStore((s) => s.style);
  const isExporting = useEditorStore((s) => s.isExporting);
  const setExporting = useEditorStore((s) => s.setExporting);
  const setExportUrl = useEditorStore((s) => s.setExportUrl);
  const setExportError = useEditorStore((s) => s.setExportError);
  const exportUrl = useEditorStore((s) => s.exportUrl);
  const exportError = useEditorStore((s) => s.exportError);

  const [showExportPanel, setShowExportPanel] = useState(false);

  async function handleExport() {
    setShowExportPanel(true);
    setExporting(true);
    setExportError(null);
    setExportUrl(null);

    try {
      const videoBlob = await fetch(videoUrl!).then((r) => r.blob());
      const formData = new FormData();
      formData.append("video", videoBlob, videoName || "source.mp4");
      formData.append("words", JSON.stringify(words));
      formData.append("style", JSON.stringify(style));

      const res = await fetch("/api/export", { method: "POST", body: formData });
      if (!res.ok) {
        const data = await res.json().catch(() => ({ error: "Export failed" }));
        throw new Error(data.error || "Export failed");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      setExportUrl(url);
    } catch (e) {
      setExportError(e instanceof Error ? e.message : "Export failed");
    } finally {
      setExporting(false);
    }
  }

  if (!videoUrl) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center gap-4 p-10 text-center">
        <p className="text-foreground/50">No project loaded yet.</p>
        <Link href="/" className="rounded-full bg-accent px-5 py-2.5 text-sm font-semibold text-[#0a0a0c]">
          Upload a video
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col">
      {/* Top bar */}
      <header className="flex items-center justify-between border-b border-border-subtle px-5 py-3">
        <div className="flex items-center gap-3">
          <Link href="/" className="text-foreground/50 hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <span className="font-display text-sm font-semibold">{videoName || "Untitled project"}</span>
        </div>
        <button
          onClick={handleExport}
          disabled={isExporting}
          className="flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-[#0a0a0c] transition-opacity hover:opacity-90 disabled:opacity-50"
        >
          {isExporting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Download className="h-4 w-4" />
          )}
          {isExporting ? "Exporting…" : "Export video"}
        </button>
      </header>

      <div className="grid flex-1 grid-cols-1 md:grid-cols-[320px_1fr_320px]">
        <aside className="border-b border-border-subtle md:border-b-0 md:border-r">
          <TranscriptSidebar />
        </aside>

        <main className="flex flex-1 flex-col items-center justify-center bg-[#070708] p-6">
          <VideoCanvas />
        </main>

        <aside className="border-t border-border-subtle md:border-t-0 md:border-l">
          <StyleDrawer />
        </aside>
      </div>

      {showExportPanel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4">
          <div className="w-full max-w-sm rounded-2xl border border-border-subtle bg-surface p-6">
            <h3 className="font-display mb-2 text-lg font-semibold">Export</h3>

            {isExporting && (
              <div className="flex items-center gap-3 text-sm text-foreground/60">
                <Loader2 className="h-4 w-4 animate-spin text-accent" />
                Rendering captions onto your video. This happens server-side and can take a
                minute for longer clips.
              </div>
            )}

            {exportError && (
              <p className="rounded-lg bg-red-950/40 px-3 py-2 text-sm text-red-300 border border-red-900/50">
                {exportError}
              </p>
            )}

            {exportUrl && !isExporting && (
              <div className="flex flex-col gap-3">
                <p className="text-sm text-foreground/60">Your video is ready.</p>
                <a
                  href={exportUrl}
                  download={`${videoName.replace(/\.[^.]+$/, "") || "capit-export"}.mp4`}
                  className="rounded-full bg-accent px-4 py-2 text-center text-sm font-semibold text-[#0a0a0c]"
                >
                  Download MP4
                </a>
              </div>
            )}

            <button
              onClick={() => setShowExportPanel(false)}
              className="mt-4 w-full rounded-full border border-border-subtle px-4 py-2 text-sm text-foreground/60 hover:text-foreground"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
