# cap.it

Kinetic, word-by-word caption editor for short-form video (Reels/TikTok/Shorts), built with Hinglish and other code-switched dialects in mind.

## What's actually built (v1, working end-to-end)

- **Landing page** with drag-and-drop video upload
- **Demo mode** — exercises the full editor with a sample Hinglish transcript, no API key needed
- **Real transcription** via OpenAI Whisper (`/api/transcribe`), word-level timestamps
- **Live editor**: 9:16 video canvas with synced kinetic caption overlay, click-to-seek transcript sidebar, inline word editing, split/merge controls
- **4 style presets** (Hormozi, MrBeast, Minimalist, Neon) plus full manual control over font, size, color, stroke, shadow, background box, position, animation, and words-per-screen
- **Real server-side export** (`/api/export`): generates an `.ass` subtitle file from your word timings + style config and burns it into the source video with ffmpeg, returning a downloadable MP4

## Running it locally

```bash
npm install
npm run dev
```

Open http://localhost:3000. Click "Try demo mode" on the upload box to test the editor without any API keys.

### Enabling real transcription

Add an OpenAI API key to `.env.local`:

```
OPENAI_API_KEY=sk-...
```

Restart the dev server. Uploads will now be transcribed via Whisper instead of using the demo transcript.

### Export requirements

The export route shells out to `ffmpeg`, which must be installed and on `PATH` on whatever machine runs the server. This works locally and on most VPS/container deployments. **It will NOT work as-is on Vercel's standard serverless functions**, which don't ship ffmpeg and have execution time/size limits unsuited to video processing. Realistic options for production export:

1. Run the app on a server with ffmpeg available (a small VPS, Railway, Fly.io, a Docker container on Render, etc.)
2. Move export to a dedicated worker (a queue + a machine/container with ffmpeg) and poll/webhook back to the frontend
3. Move to Remotion Lambda for cloud rendering (the originally-spec'd approach) — more powerful but meaningfully more setup and cost

## What's intentionally NOT built yet

- No auth, no database, no saved projects — everything lives in browser memory (Zustand) and resets on refresh. Projects aren't persisted.
- No credit/billing system.
- No custom font upload (.ttf/.otf) — style presets use Google Fonts only for now.
- No Hinglish-specific capitalization post-processing — Whisper's raw output is used as-is. Real Hinglish-aware capitalization would need a post-processing pass (rule-based or a small LLM call) on top of the transcript.
- Export visual fidelity is very close to, but not 100% pixel-identical to, the live preview — ASS subtitles don't support per-word highlight background boxes (used by the Hormozi preset's pill highlight), so that preset's export shows a color change without the background pill. Full-line background boxes (Minimalist preset) work correctly.

## Architecture notes

- `lib/types.ts` — core data model (Word, CaptionStyleConfig, presets)
- `lib/useEditorStore.ts` — Zustand store driving the whole editor
- `lib/groupWords.ts` — shared logic for chunking words into on-screen caption groups (used by both the live preview and export, so they stay in sync)
- `components/editor/CaptionOverlay.tsx` — the actual caption rendering used in the live browser preview
- `lib/export/buildAssSubtitle.ts` — converts the same word/style data into an .ass subtitle file for ffmpeg burn-in
- `app/api/transcribe/route.ts`, `app/api/export/route.ts` — the two server routes
